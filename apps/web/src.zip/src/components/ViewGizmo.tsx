import './ViewGizmo.css';
import { Box, Compass, MoveDown, MoveLeft, MoveRight, PanelTop, RotateCcw, Eye } from 'lucide-react';
import { runEditorCommand } from '../commandRuntime';

const viewItems = [
  {id:'view.top', label:'Superior', short:'Sup.', Icon:PanelTop},
  {id:'view.isometric', label:'Isométrica', short:'ISO', Icon:Box},
  {id:'view.front', label:'Frontal', short:'Frente', Icon:Eye},
  {id:'view.left', label:'Izquierda', short:'Izq.', Icon:MoveLeft},
  {id:'view.back', label:'Posterior', short:'Atrás', Icon:RotateCcw},
  {id:'view.right', label:'Derecha', short:'Der.', Icon:MoveRight},
  {id:'view.bottom', label:'Inferior', short:'Inferior', Icon:MoveDown}
] as const;

export default function ViewGizmo() {
  return <nav className="simbo-view-gizmo" aria-label="Vistas de cámara">
    <div className="view-gizmo-heading"><Compass aria-hidden="true"/><span>Vistas</span></div>
    <div className="view-gizmo-grid">{viewItems.map(({id,label,short,Icon})=><button key={id} type="button" aria-label={`Vista ${label}`} title={`Vista ${label}`} onClick={()=>runEditorCommand(id)}><Icon aria-hidden="true"/><span>{short}</span></button>)}</div>
  </nav>;
}
