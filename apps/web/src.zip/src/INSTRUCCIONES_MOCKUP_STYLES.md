SIMBO — Ajuste visual inspirado en mockups/Figma

Cambios realizados:
- NO se modificó la lógica de TSX/estado/comandos.
- Se ajustaron únicamente estilos CSS para acercar la UI a los mockups: paleta cálida, acentos naranjas/rojos, tipografía más marcada y paneles más cercanos al diseño esperado.

Archivos CSS tocados:
- src/styles/tokens.css
- src/styles/globals.css
- src/styles/shared.css
- src/App.css
- src/components/Outliner.css
- src/components/RoomPanel.css
- src/components/LibraryPanel.css
- src/components/EditorToolbar.css
- src/components/ViewControls.css
- src/components/StatusBar.css
- src/components/ScenesPanel.css
- src/components/PresentationWorkspace.css
- src/components/Inspector.css
- src/components/ViewGizmo.css
- src/components/CommandPalette.css
- src/components/EntityContextMenu.css
- src/components/Viewport.css
- src/components/ManufacturingPanel.css
- src/components/HealthPanel.css

Sugerencia:
Si quieres seguir afinando por tu cuenta, modifica principalmente:
1) src/styles/tokens.css para colores globales
2) src/styles/shared.css para inputs/botones/paneles
3) el CSS específico del componente que quieras ajustar visualmente
